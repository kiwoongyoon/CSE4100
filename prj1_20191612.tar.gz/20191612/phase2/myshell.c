/* $begin shell */
#include "myshell.h"
#include<errno.h>
#define MAXARGS   128
/* Function prototypes */
void freeLast(char*** commands);
void eval(char* cmdline);
int parseline(char* buf, char** argv);
int builtin_command(char** argv);
void yespipe(char*** cmd, char* cmdline);
char*** make_commands(char** tokens); 
void myHandler(int sig);	
int writeflag =0; 
int main()
{
	char cmdline[maxilne]; /* Command line */
	char line[50] ; /*line to read fp file  */
	char lastline[50] ; /*line to read fp file  */
	int count =0; 
	FILE *fp = NULL ; 
	fp = fopen("history2.txt", "a+") ; 
	

	while (1) {
		fseek(fp,0, SEEK_SET) ; 
		while(fgets(line,sizeof(line),fp)){
			count ++ ; 
			strcpy(lastline, line) ; 
		}
        writeflag = 0 ; 
		/* Read */
		printf("CSE4100-MP-P1> ");
		signal(SIGTSTP, myHandler);
		signal(SIGINT, myHandler);
		if(fgets(cmdline, maxilne, stdin)){
		};
		if (feof(stdin))
			exit(0);

		/* Evaluate */
		eval(cmdline);

		/*do not store cmdline when it is same to the recent one*/
		if(strncmp(lastline, cmdline, strlen(lastline)-1)==0 ||writeflag==1){
		}else{
			fprintf(fp,"%s",cmdline) ; 
			fflush(fp) ; 
		}
        writeflag = 0 ; 
	}
    fclose(fp) ; 
}
/* $end shellmain */
void yespipe(char*** cmd, char* cmdline)
{
	pid_t pid;
	int linknum=0, flag;
	int fd[2];
	signal(SIGINT, SIG_IGN); // Ignore SIGINT signal for the parent process
	while ((*cmd)[0]) {
		if(pipe(fd)){};

		if ((pid = fork()) == 0) {
			 signal(SIGINT, SIG_DFL);
			 signal(SIGTSTP, SIG_IGN);
			// Restore default SIGINT signal handling for the child process
			// If this command is not the last one, redirect stdout to the write end of the pipe
			if ((*(cmd + 1))[0]){
				dup2(fd[1], 1); // Redirect stdout to the write end of the pipe
			}
		    dup2(linknum, 0); // Redirect stdin to the read end of the previous pipe
			close(fd[0]); // Close the read end of the pipe

			if (!builtin_command(*cmd)) { // If this is not a built-in command	
				if (execvp((*cmd)[0], *cmd) < 0) { // Try to execute the command
					printf("%s: Command not found.\n", (*cmd)[0]); // If command not found, print an error message
					exit(0);
				}
			}
			else
				exit(0);
		}else {
			if (waitpid(pid, &flag, 0) < 0) // Wait for the child process to terminate
				unix_error("waitfg: waitpid error");
			close(fd[1]); // Close the write end of the pipe
			linknum = fd[0]; //store output to the linknum and use linknum to do stdin in next cmd child
			cmd++; // Move on to the next command
		}
	}
}

void nopipe(char** cmd)
{
    int flag;
    pid_t pid;
    FILE *fp1 = NULL ; 
    fp1 = fopen("history2.txt", "a+") ; 
    char line[50] ; 
    char lastline[50] ; 
        fseek(fp1, 0 , SEEK_SET) ;
    while (fgets(line, sizeof(line), fp1)){
            line[strlen(line)-1]='\0'; 
            strcpy(lastline , line) ;
         }
	//when cmd of history comes 
	if( strcmp("history", cmd[0])==0){  
        fseek(fp1, 0 , SEEK_SET) ;
        int his_cnt = 1 ; 
        while (fgets(line, sizeof(line), fp1)){
                line[strlen(line)-1]='\0'; 
                printf("%d %s\n",his_cnt, line) ; 
                his_cnt ++ ; 
                strcpy(lastline , line) ;
            }
         if(strncmp(lastline,"history",7)!=0){
         fprintf(fp1,"%s","history\n") ; 
		 fflush(fp1) ;    

         }
        writeflag = 1 ; 
        fclose(fp1) ; 
        return ; 
	}
    fclose(fp1) ; 

    /* Create a child process to execute the command */
    if ((pid = fork()) == 0) {
        /* In the child process, execute the command */
        if (execvp(cmd[0], cmd) < 0) {
            /* If execvp returns -1, the command was not found */
            printf("%s: Command not found. \n", cmd[0]);
            exit(0);
        }
    }
    else {
        /* In the parent process, wait for the child process to finish */
        if ((pid = waitpid(pid, &flag, WUNTRACED)) < 0) {
            /* If waitpid returns -1, there was an error waiting for the child process */
            unix_error("waitfg: waitpid error");
        }
    }
}


/* $begin eval */
/* eval - Evaluate a command line */
void eval(char* cmdline)
{
	char* argv[MAXARGS]; /* Argument list execve() */
	char buf[maxilne];   /* Holds modified command line */
	pid_t pid;           /* Process id */
	int bg;              /* Should the job run in bg or fg? */
	char*** cmd;

    FILE *fp2 = NULL ; 
	fp2 = fopen("history2.txt", "a+") ; 
	char line[50], lastline[50] ; 
    fseek(fp2, 0 , SEEK_SET) ;
    while (fgets(line, sizeof(line), fp2)){
            line[strlen(line)-1]='\0'; 
            strcpy(lastline , line) ;
         }

	strcpy(buf, cmdline);//줄바꿈 문자 첨에 있어 
    // printf("%s: the first one \n " , buf) ; 
	bg = parseline(buf, argv);// 파이프 기호도 하나의 문자열로 보고 따로 저장 
    
	if (argv[0] == NULL)
		return;   /* Ignore empty lines */

	if (!builtin_command(argv)) {
        
        if((strcmp(argv[0],"!!")==0)&& (strlen(cmdline)==3)){// when !! is the cmdline 
            FILE *qfp=NULL ; 
            qfp = fopen("history2.txt","a+" ); 
            fseek(qfp, 0, SEEK_SET); 
            while(fgets(line,sizeof(line) ,qfp )){
                strcpy(lastline, line) ; 
            }
            writeflag = 1 ; 
            lastline[strlen(lastline)-1] = '\n' ; 
             strcpy(buf, lastline) ;
             
            if(!strchr(buf, '|')){
                
                parseline(buf,argv) ; 
                cmd = make_commands(argv); 
                if(!cmd[1][0]){
                   if(!builtin_command(argv)){  nopipe(argv) ;    }
                       } 
                freeLast(cmd);
                fclose(fp2) ;        
                return ;
            }else{//!! 의 명령어가 파이프 있는 경우 
                parseline(lastline , argv) ; 
                cmd= make_commands(argv) ; 
                if(cmd[1][0]){
                    yespipe(cmd, lastline) ; 
                }
                freeLast(cmd);
                writeflag = 1 ; 
                fclose(fp2) ;
                return ;
            }   
        }
        

        else if(strncmp(argv[0],"!",1 )==0 && (strchr(cmdline, '|')==NULL)){ //when !# is the cmdline 
            fseek(fp2, 0 , SEEK_SET) ;
            int num  ; 
            char *num_pos = argv[0] ; 
            if(sscanf(num_pos+1 , "%d", &num)==1){
                }
            int linenum =1 ;
            char numline[50] ; 
            char torun[50] ; 
             while (fgets(line, sizeof(line), fp2)) {
                        strcpy(numline, line);
                        if(linenum == num){
                            strcpy(torun , numline) ; 
                        }
                        linenum++;
                     }
                    fprintf(fp2,"%s",torun) ; 
			        fflush(fp2) ; 
                    if(strchr(torun , '|')==NULL){
                        torun[strlen(torun)-1]= '\n' ;
                        parseline(torun,argv) ;
                        cmd = make_commands(argv); 
                        if(!cmd[1][0]){
                            if(!builtin_command(argv)){
                                nopipe(argv) ; 
                            }
                        }else{
                        }
                        writeflag = 1 ;
                        freeLast(cmd);
                        fclose(fp2) ; 
                        return ;

                    }else{
                        // !#가 파이프라인 갖을 경우 
                        torun[strlen(torun)-1]= '\n' ; 
                        strcpy(buf,torun) ; 
                        parseline(buf, argv);
                        cmd = make_commands(argv);
                        yespipe(cmd, torun ) ;
                        writeflag = 1 ; 
                        freeLast(cmd);
                        fclose(fp2) ; 
                        return ;
                    }
        }
		cmd = make_commands(argv);
		if (cmd[1][0]){
			yespipe(cmd, cmdline);
		}
		else{
			 nopipe(argv);
		}
		freeLast(cmd);
	}
    fclose(fp2) ; 
	return;
}

void freeLast(char*** commands)
{
	for (int i = 0; i < MAXARGS; i++) {
		for (int j = 0; j < MAXARGS; j++) {
			free(commands[i][j]);
		}
		free(commands[i]);
	}
	free(commands);
}


char*** make_commands(char** tokens) {
    int count =0 ; 
    char line[100] ; 
    char lastline[100] ; 

    FILE *pipefp = NULL ; 
    pipefp = fopen("history2.txt", "a+") ;
    fseek(pipefp, 0, SEEK_SET); 
     while (fgets(line, sizeof(line), pipefp)) {
            //store the last line of the txt file to compare with the comming command line 
            count++;
            strcpy(lastline, line);
        }
    lastline[strcspn(lastline,"\n")]='\0'; 
    char*** commands = (char***) malloc(MAXARGS * sizeof(char**));
    int command_index = 0;
    int argument_index = 0;
    
    // allocate memory for each command and argument
    for (int i = 0; i < MAXARGS; i++) {
        commands[i] = (char**) malloc(MAXARGS * sizeof(char*));
        for (int j = 0; j < MAXARGS; j++) {
            commands[i][j] = (char*) malloc(MAXARGS * sizeof(char));
        }
    }

    // loop through each token
    while (*tokens != NULL) {
        char* token = *tokens;
        int argument_len = strlen(token);
        int has_pipe = 0;

        // check if token has a pipe character
        for (int i = 0; i < argument_len; i++) {
            if (token[i] == '|') {
                has_pipe = 1;
                break;
            }
        }

        // if token has a pipe character
        if (has_pipe) {
            // terminate current command and start a new one
            commands[command_index][argument_index] = NULL;
            command_index++;
            argument_index = 0;
            tokens++;
            
            // add next argument to new command
            if (*(token + 1)) {
                // determine starting index of next argument
                int start_index = (*token == '|') ? 1 : 0;
                int k = 0;
                for (int i = start_index; i < argument_len; i++) {
                    char current_char = token[i];
                    if (current_char == '\'' || current_char == '\"') {
                        continue;
                    }
                    commands[command_index][argument_index][k] = current_char;
                    k++;
                }
                commands[command_index][argument_index][k] = '\0';
                argument_index++;
            }
        } else {
            // add argument to current command
            int k = 0;
            for (int i = 0; i < argument_len; i++) {
                char current_char = token[i];
                if (current_char == '\'' || current_char == '\"') {
                    continue;
                }
                commands[command_index][argument_index][k] = current_char;
                k++;
            }
            commands[command_index][argument_index][k] = '\0';
            argument_index++;
            tokens++;
        }
    }

    // terminate last command and set next command to NULL
    commands[command_index][argument_index] = NULL;
    commands[command_index + 1][0] = NULL;

    if( !strcmp(commands[0][0],"history")){
    }
    if (!strncmp(commands[0][0],"!",1)){
        if(!strncmp(commands[0][0],"!!",2)){  //제일 최근 명령어 찾기 
            if(strlen(commands[0][0])==2){
                memset(commands[0][0], 0, sizeof(commands[0][0])); 
                strcpy(commands[0][0],lastline); 
            }
            else if(strlen(commands[0][0])>2){
                char temp[100] ;
                char newcmdline[100] ; 
                char *pos = strstr(commands[0][0], "!!") ; 
                if(pos!=NULL){
                    strncpy(temp, commands[0][0], pos-commands[0][0]) ; 
                    temp[pos-commands[0][0]] = '\0' ; 
                    lastline[strcspn(lastline, "\n")]= '\0' ; 
                    strcat(temp ,lastline) ; 
                    strcat(temp, pos+2) ; 
                    strcpy(newcmdline, temp) ; 
                    memset(commands[0][0], 0, sizeof(commands[0][0]));
                    strcpy(commands[0][0], newcmdline) ;
                    
                }
            }
        }
        else{
            char *num_pos = commands[0][0] ; 
            if(strncmp(num_pos,"!", 1)==0){
                int num ; 
                if(sscanf(num_pos+1, "%d",&num)==1){
                }
                fseek(pipefp,0, SEEK_SET) ; 
                int line_number = 1 ;
                char numline[50] ; 
                char torun[50] ; 
                     while (fgets(line, sizeof(line), pipefp)) {
                        strcpy(numline, line);
                        if(line_number == num){
                            strcpy(torun , numline) ;
                        }
                        line_number ++;
                     }
                     memset(commands[0][0], 0, sizeof(commands[0][0]));
                     torun[strcspn(torun,"\n")]= '\0';  
                    strcpy(commands[0][0], torun) ;
            }
        }
    }
    fclose(pipefp) ; 
    return commands;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char** argv)
{
	if (!strcmp(argv[0], "exit")) /* quit command */
		exit(0);
	if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	if (!strcmp(argv[0], "cd")) {
		if (argv[1]) {
			if (chdir(argv[1]))printf("-bash: cd: %s: No such file or directory\n", argv[1]);
		}
		else
			if(chdir(getenv("HOME"))){
			};
		return 1;
	}
	return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char* buf, char** argv) {
    char* tmp;
    char* delim;     // Points to first space delimiter
    int argc;        // Number of args
    int bg;          // Background job?

    buf[strlen(buf) - 1] = ' ';   // Replace trailing '\n' with space

    // Ignore leading spaces
    while (*buf && (*buf == ' ')) {
        buf++;
    } 

    // Build the argv list
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
        if (*buf == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        } else if (*buf == '\"') {
            buf++;
            delim = strchr(buf, '\"');
        }
        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;

        // Ignore spaces
        while (*buf && (*buf == ' ')) {
            buf++;
        } 
    }
    argv[argc] = NULL;
// Ignore blank line
    if (argc == 0) {
        return 1;
    } 
    tmp = argv[argc - 1];
    if (tmp[strlen(tmp) - 1] == '&' || *argv[argc - 1] == '&') {
        bg = 1;
    } else {
        bg = 0;
    }
    return bg;
}
/* $end parseline */
void myHandler(int sig) {
	printf("\nCSE4100-MP-P1> \n");
}
