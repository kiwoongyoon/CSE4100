#ifndef __SHELLEX_H__
#define __SHELLEX_H__

#include "csapp.h"
#include<errno.h>

void dirchange(char *cmdline);
char *maketoken(char *cmdline);
int builtin_command(char **argv);
void eval(char *cmdline);
void handler(int sig);
 void pipeCMD(char* cmdline);
#endif