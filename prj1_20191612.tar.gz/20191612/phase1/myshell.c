/* $begin shellmain */
#include "csapp.h"

#include"shellex.h"

#include<errno.h>
// #include<string>
#define MAXARGS   128 
/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 

// main starts
int main() 
{
   char cmdline[MAXLINE]; /* Command line */
   char lastline[50]; 
   char line[100];
   int num ;
   int count = 0 ; 
   int isfirst = 1 ;
   
    signal(SIGINT, handler); 
    signal(SIGQUIT, handler); 
 
    //make file to do history 
    FILE *fp = NULL ; 
    fp = fopen("history.txt", "a+") ; 
    

    while (1) {
        int isdone = 0 ;
        //when command line is about history or !!, !# 
        //make isdone to 1 so that eval does not work twice


        fseek(fp, 0, SEEK_SET); 
        /* Read */
        printf("CSE4100-MP-P1> ");                   
        if (fgets(cmdline, MAXLINE, stdin) == NULL) {
            if (feof(stdin)) {
                exit(0);
            } else {
                printf("Error reading input: %s\n", strerror(errno));
                continue;
            }
        }
        while (fgets(line, sizeof(line), fp)) {
            //store the last line of the txt file to compare with the comming command line 
            count++;
            strcpy(lastline, line);
        }

         

         
        if((strncmp("!", cmdline, 1) ==0)){
           //when command line starts with ! 
           //divide the case for each 
            if ((strncmp("!!", cmdline,2)==0)){
            //when it gets the lastest command from history.txt file 
            if(strlen(cmdline)==3){
                //skip writing cmdline in txt file 
                eval(lastline) ; 
                isdone = 1 ;
            }
            else if(strlen(cmdline)> 3){
                // change commandline to newcmdline so that it can the function
                // eval can work well, write to the history.txt because newcmdline
                //is different from the command line right before 
                char temp[MAXLINE] ; 
                char newcmdline[MAXLINE] ;  
                char *pos = strstr(cmdline, "!!") ; 
                if(pos!=NULL){
                    strncpy(temp, cmdline, pos-cmdline) ; 
                    temp[pos-cmdline] = '\0' ; 
                    lastline[strcspn(lastline, "\n")]= '\0' ; 
                    strcat(temp ,lastline) ; 
                    strcat(temp, pos+2) ; 
                    strcpy(newcmdline, temp) ; 
                }
                // printf(" it is the new line : %s\n", newcmdline) ; 
                fprintf(fp,"%s", newcmdline) ; 
                eval(newcmdline) ; 
                isdone = 1 ; 
            }
          }
            else{
                // Case when a number comes right after the question mark 
                // get the right past command line and store in torun array 
                char *num_pos = cmdline ; 
                if(strncmp(num_pos , "!", 1)==0){
                    int num ;
                    if(sscanf(num_pos+1 , "%d", &num)==1){
                    }
                    fseek(fp, 0, SEEK_SET); 
                    int linenum =1 ;
                    char numline[50] ; 
                    char torun[50] ; 
                     while (fgets(line, sizeof(line), fp)) {
                        strcpy(numline, line);
                        if(linenum == num){
                            strcpy(torun , numline) ; 
                            // printf("found the line matches :%s \n", torun); 
                            eval(torun) ; 
                            isdone = 1; 
                        }
                        linenum++;
                     }
                     if(strcmp(torun,numline)!=0){
                        fprintf(fp, "%s",torun) ;
                     }
                } 
            }
        }



        /* Evaluate when cmdline was not evaled before it */
        if(isdone==0){
            eval(cmdline);
           
            if(strncmp(lastline,cmdline, strlen(lastline)-1)==0){
               
            }else{
                fprintf(fp, "%s", cmdline) ; 
                fflush(fp) ; 
            }

            
            
        }


    
    }
    
    fclose(fp)  ; 
}




/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    
    if((strncmp("history",cmdline, 7)==0)&&(strlen(cmdline)>8)){
        cmdline[strlen(cmdline)-1]  ='\0'; 
        printf("%s: Command not found.\n", cmdline);
        return  ; 
                
    }
    strcpy(buf, cmdline);
    
    if(strncmp(buf,"exit", 4)==0){
        exit(0); 
    }
    bg = parseline(buf, argv); 
    if (argv[0] == NULL)  {
	    return;   /* Ignore empty lines */
    }


    // In the case it is not built in command 
    if(builtin_command(argv)){
        return ; 
    }
    //quit -> exit(0), & -> ignore, other -> run
         if((pid= Fork())==0){
             if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
                printf("%s: Command not found.\n", argv[0]);
                exit(0);
            }
       }
       


	/* Parent waits for foreground job to terminate */
	if (!bg){ 
	    int statuss;
        if(waitpid(pid, &statuss,0 )< 0 ){
            unix_error("waitpid err");
         }
	}
	else{
	    printf("%d %s", pid, cmdline);
    //when there is backgrount process!
    }
    
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit")){
	    exit(0);  

    } /* quit command */
    if (!strcmp(argv[0], "&")) {
        return 1 ; 
    }  /* Ignore singleton & */
	if (!strncmp(argv[0], "cd",2)) {
        dirchange(argv[1]); // Handle cd command
        return 1;
    }

    if(!strcmp(argv[0], "history")){
       
        
         FILE *fp1 = NULL ; 
         fp1 = fopen("history.txt", "a+") ; 
         char line[50] ; 
         char lastline[50] ; 
        fseek(fp1, 0 , SEEK_SET) ;
        int his_cnt = 1 ; 
        while (fgets(line, sizeof(line), fp1)){
                line[strlen(line)-1]='\0'; 
                printf("%d %s\n",his_cnt, line) ; 
                his_cnt ++ ; 
                strcpy(lastline , line) ;
            }
        
        
        
        fclose(fp1) ; 
        return 1; 
    }




    return 0;                     /* Not a builtin command */
}
/* $end eval */

int parseline(char* buf, char** argv)
{
	int bg, argc;              /* Background job?  Number of args */
	char* delim;         /* Points to first space delimiter */
	buf[strlen(buf) - 1] = ' ';  
    /* Replace trailing '\n' with space */
    /* erase the first blank spaces  */
	while (*buf && (*buf == ' ')) {
		buf++;
    }
	/* Build the argv list */
	argc = 0;
	while ((delim = strchr(buf, ' '))) {
       /* recognize the ' or " in the buf to erase it */ 
		if (*buf == '\"') {
			buf++;
			delim = strchr(buf, '\"');
		}else if (*buf == '\'') {
			buf++;
			delim = strchr(buf, '\'');
		}
		argv[argc++] = buf;
		*delim = '\0';
        //cut the buf with \0 where the space is in the argv 
		buf = delim + 1;
        /* Ignore spaces */
		while (*buf && (*buf == ' ')){
			buf++;
        } 
	}
	argv[argc] = NULL;

	if (argc == 0)  /* Ignore blank line */
		return 1;

	/* Should the job run in the background? */
	if ((bg = (*argv[argc - 1] == '&')) != 0)
		argv[--argc] = NULL;

	return bg;
}


void dirchange(char* cmdline) {
	//function that handles command line about "cd" 
    
    if (cmdline == NULL) { // if no argument is given, change to home directory
        cmdline = getenv("HOME");
    }
    if (chdir(cmdline) != 0) {
        perror("cd");
    }
}
void handler(int sig) {
	printf("\nCSE4100-MP-P1>\n");
}

