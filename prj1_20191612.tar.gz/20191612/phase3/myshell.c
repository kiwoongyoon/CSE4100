/* $begin shellmain */
#include "csapp.h"
#include<errno.h>
#define MAXARGS   128
#define maxilne 100

/* Function prototypes */

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 
void freeLast(char*** commands);
// void printjobs(); 
void addjob(pid_t pid, char*cmdline, int state) ; 
void myHandler(int sig) ; 
void myChildHandler(int sig);
void myStpHandler(int sig);
void yespipe(char*** cmd, char* cmdline);
char*** make_commands(char** tokens); 
void nopipe(char** cmd,int bg) ; 

int writeflag =0 ; 
int ch_pid =-1 ; 
int job_cnt  = 1 ;

char cmdline[MAXLINE]; /* Command line */
#define NONE	0
#define FRUN	1//앞에서 실행
#define BRUN	2//뒤에서 실행 	
#define SUSB	3//뒤에서 중단된 경우
#define DONE	4	
#define KILL	5

typedef struct job{
    pid_t pid ; int id ; char cmd[MAXLINE]; int status ; 
    
} jobs ; 
jobs joblist[MAXARGS] ; 


int main() 
{
    
    // char cmdline[MAXLINE]; /* Command line */
    char line[50] ; /*line to read fp file  */
	char lastline[50] ; /*line to read fp file  */
    int count =0; 
	FILE *fp = NULL ; 
	fp = fopen("history3.txt", "a+") ; 

 
    while (1) {
        /* Get the last line of history file */
        fseek(fp,0, SEEK_SET) ; 
		    while(fgets(line,sizeof(line),fp)){
		    	count ++ ; 
		    	strcpy(lastline, line) ; 
		    }
        
		 signal(SIGINT, myHandler);// ctrl c 
        // signal(SIGTSTP, SIGTSTPhandler); ctrl z 
		// signal(SIGCHLD, SIGCHLDhandler);
    
	    /* Read */
	    printf("CSE4100-MP-P1> ");                 
	    if(fgets(cmdline, MAXLINE, stdin)); 
	    if (feof(stdin))
	        exit(0);

	    /* Evaluate */
	    eval(cmdline);

        /*txt파일에 작성할까? */
        if(strncmp(lastline, cmdline, strlen(lastline)-1)==0 ||writeflag==1){
		}else{
			fprintf(fp,"%s",cmdline) ; 
			fflush(fp) ; 
		}
        writeflag = 0 ; 
    } 

    fclose(fp) ; 
}

void yespipe(char*** cmd, char* cmdline)
{
	pid_t pid;
	int linknum=0, flag;
	int fd[2];
	signal(SIGINT, SIG_IGN); // Ignore SIGINT signal for the parent process
	while ((*cmd)[0]) {
		if(pipe(fd)){};

		if ((pid = fork()) == 0) {
			signal(SIGINT, SIG_DFL);
			signal(SIGTSTP, SIG_IGN);
			// Restore default SIGINT signal handling for the child process
			// If this command is not the last one, redirect stdout to the write end of the pipe
			if ((*(cmd + 1))[0]){
				dup2(fd[1], 1); // Redirect stdout to the write end of the pipe
			}
		    dup2(linknum, 0); // Redirect stdin to the read end of the previous pipe
			close(fd[0]); // Close the read end of the pipe

			if (!builtin_command(*cmd)) { // If this is not a built-in command	
				if (execvp((*cmd)[0], *cmd) < 0) { // Try to execute the command
					printf("%s: Command not found.\n", (*cmd)[0]); // If command not found, print an error message
					exit(0);
				}
			}
			else
				exit(0);
		}else {
			if (waitpid(pid, &flag, 0) < 0) // Wait for the child process to terminate
				unix_error("waitfg: waitpid error");
			close(fd[1]); // Close the write end of the pipe
			linknum = fd[0]; //store output to the linknum and use linknum to do stdin in next cmd child
			cmd++; // Move on to the next command
		}
	}
}

void nopipe(char** cmd, int bg)
{
    int flag;
    int isback ; //bg 인지 알려주는 거
    int state = 1 ; 
    pid_t pid;
    FILE *fp1 = NULL ; 
    fp1 = fopen("history3.txt", "a+") ; 
    char line[50] ; 
    char lastline[50] ; 
        fseek(fp1, 0 , SEEK_SET) ;
    while (fgets(line, sizeof(line), fp1)){
            line[strlen(line)-1]='\0'; 
            strcpy(lastline , line) ;
         }
	if( strcmp("history", cmd[0])==0){  //when cmd of history comes 
        fseek(fp1, 0 , SEEK_SET) ;
        int his_cnt = 1 ; 
        while (fgets(line, sizeof(line), fp1)){
                line[strlen(line)-1]='\0'; 
                printf("%d %s\n",his_cnt, line) ; 
                his_cnt ++ ; 
                strcpy(lastline , line) ;
            }
         if(strncmp(lastline,"history",7)!=0){
         fprintf(fp1,"%s","history\n") ; 
		 fflush(fp1) ;    

         }
        writeflag = 1 ; 
        fclose(fp1) ; 
        return ; 
	}
   //////////eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee//////////
    printf("%d\n", bg) ; 
    if ((pid = fork()) == 0) {
        if(bg==0){
            signal(SIGINT, SIG_DFL) ; 

        }else{
			signal(SIGTSTP, SIG_IGN);
            signal(SIGINT, SIG_IGN);
            ch_pid = getpid() ; 
            addjob(ch_pid, cmdline,1);
        }
        /* In the child process, execute the command */
        if (execvp(cmd[0], cmd) < 0) {
            /* If execvp returns -1, the command was not found */
            printf("%s: Command not found. \n", cmd[0]);
            exit(0);
        }
    }
    // 부모프로세스 시작 (백그라운드 아니면 평상시 작동 )
    if(bg==0){
        ch_pid = pid ;
        if ((pid = waitpid(pid, &flag, WUNTRACED)) < 0) {
            /* If waitpid returns -1, there was an error waiting for the child process */
            unix_error("waitfg: waitpid error");
        }
        if(WIFEXITED(flag)) {
					ch_pid = -1;
		}
    }
    else {
        addjob(pid, cmdline,1);
    }
    return ;

    
}
/* eval - Evaluate a command line */
void eval(char* cmdline)
{
	char* argv[MAXARGS]; /* Argument list execve() */
	char buf[maxilne];   /* Holds modified command line */
	pid_t pid;           /* Process id */
	int bg;              /* Should the job run in bg or fg? */
	char*** cmd;

    FILE *fp2 = NULL ; 
	fp2 = fopen("history3.txt", "a+") ; 
	char line[50], lastline[50] ; 
    fseek(fp2, 0 , SEEK_SET) ;
    while (fgets(line, sizeof(line), fp2)){
            line[strlen(line)-1]='\0'; 
            strcpy(lastline , line) ;
         }

	strcpy(buf, cmdline);//줄바꿈 문자 첨에 있어 
    // printf("%s: the first one \n " , buf) ; 
	bg = parseline(buf, argv);// 파이프 기호도 하나의 문자열로 보고 따로 저장 
    
	if (argv[0] == NULL)
		return;   /* Ignore empty lines */

	if ((!builtin_command(argv))&&(bg==0)) {
        
        if((strcmp(argv[0],"!!")==0)&& (strlen(cmdline)==3)){// when !! is the cmdline 
            FILE *qfp=NULL ; 
            qfp = fopen("history3.txt","a+" ); 
            fseek(qfp, 0, SEEK_SET); 
            while(fgets(line,sizeof(line) ,qfp )){
                strcpy(lastline, line) ; 
            }
            writeflag = 1 ; 
            lastline[strlen(lastline)-1] = '\n' ; 
             strcpy(buf, lastline) ;
             
            if(!strchr(buf, '|')){
                
                parseline(buf,argv) ; 
                cmd = make_commands(argv); 
                if(!cmd[1][0]){
                   if(!builtin_command(argv)){  nopipe(argv,bg) ;    }
                       } 
                // freeLast(cmd);
                fclose(fp2) ;        
                return ;
            }else{//!! 의 명령어가 파이프 있는 경우 
                parseline(lastline , argv) ; 
                cmd= make_commands(argv) ; 
                if(cmd[1][0]){
                    yespipe(cmd, lastline) ; 
                }
                // freeLast(cmd);
                fclose(fp2) ;
                return ;
            }   
        }
        

        else if(strncmp(argv[0],"!",1 )==0 && (strchr(cmdline, '|')==NULL)){ //when !# is the cmdline 
            fseek(fp2, 0 , SEEK_SET) ;
            int num  ; 
            char *num_pos = argv[0] ; 
            if(sscanf(num_pos+1 , "%d", &num)==1){
                }
            int linenum =1 ;
            char numline[50] ; 
            char torun[50] ; 
             while (fgets(line, sizeof(line), fp2)) {
                        strcpy(numline, line);
                        if(linenum == num){
                            strcpy(torun , numline) ; 
                        }
                        linenum++;
                     }
                    fprintf(fp2,"%s",torun) ; 
			        fflush(fp2) ; 
                    if(strchr(torun , '|')==NULL){
                        torun[strlen(torun)-1]= '\n' ;
                        parseline(torun,argv) ;
                        cmd = make_commands(argv); 
                        if(!cmd[1][0]){
                            if(!builtin_command(argv)){
                                nopipe(argv,bg) ; 
                            }
                        }else{
                        }
                        writeflag = 1 ;
                        // freeLast(cmd);
                        fclose(fp2) ; 
                        return ;

                    }else{
                        // !#가 파이프라인 갖을 경우 (파일쓰기까지 완벽)
                        torun[strlen(torun)-1]= '\n' ; 
                        strcpy(buf,torun) ; 
                        parseline(buf, argv);
                        cmd = make_commands(argv);
                        yespipe(cmd, torun ) ;
                        writeflag = 1 ; 
                        // freeLast(cmd);
                        fclose(fp2) ; 
                        return ;
                    }
        }
		
        
        
        
        
        cmd = make_commands(argv);
		if (cmd[1][0]){
			yespipe(cmd, cmdline);
		}
		else{
			 nopipe(argv,bg);
		}
		// freeLast(cmd);
	}
    fclose(fp2) ; 
	return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char** argv)
{
    int jobnum =0 ; //프로세스 번호 지칭
	if (!strcmp(argv[0], "exit")) /* quit command */
		exit(0);
	if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	if (!strcmp(argv[0], "cd")) { // 파일 디렉토리 변경할 때
		if (argv[1]) {
			if (chdir(argv[1]))printf("-bash: cd: %s: No such file or directory\n", argv[1]);
		}
		else
			if(chdir(getenv("HOME"))){
			};
		return 1;
	}
    if(!strcmp(argv[0], "jobs")) {//프로세스 열린 것 보여주는 것 
         printf("hihi it is jobs\n") ; 
		for(int i = 0; i < MAXARGS; i++) {
		if((joblist[i].status == BRUN)||(joblist[i].status == SUSB)) {
			// printf("[%d]  running   %s", joblist[i].id, joblist[i].cmd);
            printf("[%d]   %s    %s", joblist[i].id, (joblist[i].status == BRUN) ? "running" : "suspended", joblist[i].cmd);
		}else{
         

        }
        // else
        // {printf("%d is number \n ", i ); 
		// }// else if(joblist[i].status == SUSB) {
		// 	printf("[%d]\tsuspended\t%s", joblist[i].id, joblist[i].cmd);
		// }
	}
		return 1;
	}
    
    if(!strcmp(argv[0], "kill")){// kill %n 에 대한 명령어처리 
        
        if(!argv[1] || (argv[1][0] !='%')){//그냥 kill만 입력 
            printf("Usage : kill %%job id\n");
			return 1;
        }
        if(argv[1][1]!=0){
        
            jobnum  = atoi(&argv[1][1]) ; 
            if(joblist[jobnum].status == NONE){
                printf("No Such Job\n"); 
            }
            else{
                Kill(joblist[jobnum].pid, SIGKILL) ; 
                joblist[jobnum].status = KILL ; 
                // return 1 ;     
            }

            return 1; 
        }else{
            printf("Usage : kill %%job id\n");
			return 1;
        }
    }

    if(!strcmp(argv[0], "bg")){// 백그라운드 실행에 대한 명령
        
        if((!argv[1] )||(argv[1][0]!= '%')){
            printf("Usage : bg %%job id\n"); return 1;
        }
        if(argv[1][1]){
            jobnum = atoi(&argv[1][1]) ; 
            if(joblist[jobnum].status ==BRUN){
               printf("Already running\n");return 1 ; 
            }else if(joblist[jobnum].status==NONE){
                printf("No Such Job\n");
				return 1;
            }else if(joblist[jobnum].status ==DONE|| joblist[jobnum].status==KILL){
                printf("No Such Job\n");
				return 1;
            }else{
                printf("[%d]  running     %s", joblist[jobnum].id, joblist[jobnum].cmd) ; 
                // KILL(joblist[jobnum].pid, SIGCONT) ; 
                joblist[jobnum].status = BRUN ; 
                return 1 ; 
            }
        }
        return 1; 
    }

    if(!strcmp(argv[0], "fg")){// 앞에서 실행되는 것들 명령처리 
        if(!argv[1] ||(argv[1][0]!='%')) {
			printf("Usage : fg %%job id\n");
			return 1;
		}
        if(argv[1][1]){
            jobnum = atoi(&argv[1][1]) ; 
            if(joblist[jobnum].status == FRUN){
                printf("Already Running\n");
				return 1;
            }else if(joblist[jobnum].status == NONE || joblist[jobnum].status == DONE )
            {
                printf("No Such Job\n");
				return 1;
            }else if(joblist[jobnum].status == KILL){
                printf("No Such Job\n");
				return 1;
            }else if(joblist[jobnum].status==SUSB ||joblist[jobnum].status == BRUN){
                Kill(joblist[jobnum].pid, SIGCONT) ; 
                joblist[jobnum].status = FRUN ; 
                printf("[%d]  running     %s", joblist[jobnum].id, joblist[jobnum].cmd) ;
                waitpid(joblist[jobnum].pid, NULL, WUNTRACED);
                // Check if the process was stopped by a signal
                if (WIFSTOPPED(joblist[jobnum].status)) {//여기 if랑 else 새로변경 
                    joblist[jobnum].status = SUSB;
                    printf("[%d]  suspended     %s", joblist[jobnum].id, joblist[jobnum].cmd);
                    
                }
                else {
                    // Process finished executing
                    joblist[jobnum].status= KILL; 
                }
                // while(1) {
				// 	if(jobList[jobId].state != FRUN) {
				// 		break;
				// 	}
				// }
                return 1; 
            }
        }
        return 1 ; 
    }


	return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char* buf, char** argv) {
    char* tmp;
    char* delim;     // Points to first space delimiter
    int argc;        // Number of args
    int bg=0;          // Background job?

    buf[strlen(buf) - 1] = ' ';   // Replace trailing '\n' with space

    // Ignore leading spaces
    while (*buf && (*buf == ' ')) {
        buf++;
    } 

    // Build the argv list
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
        if (*buf == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        } else if (*buf == '\"') {
            buf++;
            delim = strchr(buf, '\"');
        }
        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;

        // Ignore spaces
        while (*buf && (*buf == ' ')) {
            buf++;
        } 
    }
    argv[argc] = NULL;
// Ignore blank line
    if (argc == 0) {
        return 1;
    } 
    tmp = argv[argc - 1];
    if (tmp[strlen(tmp) - 1] == '&' || *argv[argc - 1] == '&') {
        bg = 1;
        argv[argc-1][strlen(argv[argc-1])-1] = '\0'; //새로추가 해쓴다 
    } else {
        bg = 0;
    }

    
    return bg;
}

// void printjob() {
// 	for(int i = 0; i < MAXARGS; i++) {
// 		if(joblist[i].status == BRUN) {
// 			printf("[%d]\trunning  \t%s", joblist[i].id, joblist[i].cmd);
// 		}
// 		else if(joblist[i].status == SUSB) {
// 			printf("[%d]\tsuspended\t%s", joblist[i].id, joblist[i].cmd);
// 		}
// 	}
// }

void addjob(pid_t pid , char * cmdline, int state) {
	joblist[job_cnt].id = job_cnt;
	strcpy(joblist[job_cnt].cmd, cmdline);
    joblist[job_cnt].pid = pid;
	joblist[job_cnt].status = state;
	job_cnt++;
}

void myHandler(int sig) {
	printf("CSE4100-MP-P1> ");
}

void myChildHandler(int sig){
    
}
void myStpHandler(int sig){
    
}

char*** make_commands(char** tokens) {
    int count =0 ; 
    char line[100] ; 
    char lastline[100] ; 

    FILE *pipefp = NULL ; 
    pipefp = fopen("history3.txt", "a+") ;
    fseek(pipefp, 0, SEEK_SET); 
     while (fgets(line, sizeof(line), pipefp)) {
            //store the last line of the txt file to compare with the comming command line 
            count++;
            strcpy(lastline, line);
        }
    lastline[strcspn(lastline,"\n")]='\0'; 



    char*** commands = (char***) malloc(MAXARGS * sizeof(char**));
    int command_index = 0;
    int argument_index = 0;
    
    // allocate memory for each command and argument
    for (int i = 0; i < MAXARGS; i++) {
        commands[i] = (char**) malloc(MAXARGS * sizeof(char*));
        for (int j = 0; j < MAXARGS; j++) {
            commands[i][j] = (char*) malloc(MAXARGS * sizeof(char));
        }
    }

    // loop through each token
    while (*tokens != NULL) {
        char* token = *tokens;
        int argument_len = strlen(token);
        int has_pipe = 0;

        // check if token has a pipe character
        for (int i = 0; i < argument_len; i++) {
            if (token[i] == '|') {
                has_pipe = 1;
                break;
            }
        }

        // if token has a pipe character
        if (has_pipe) {
            // terminate current command and start a new one
            commands[command_index][argument_index] = NULL;
            command_index++;
            argument_index = 0;
            tokens++;
            
            // add next argument to new command
            if (*(token + 1)) {
                // determine starting index of next argument
                int start_index = (*token == '|') ? 1 : 0;
                int k = 0;
                for (int i = start_index; i < argument_len; i++) {
                    char current_char = token[i];
                    if (current_char == '\'' || current_char == '\"') {
                        continue;
                    }
                    commands[command_index][argument_index][k] = current_char;
                    k++;
                }
                commands[command_index][argument_index][k] = '\0';
                argument_index++;
            }
        } else {
            // add argument to current command
            int k = 0;
            for (int i = 0; i < argument_len; i++) {
                char current_char = token[i];
                if (current_char == '\'' || current_char == '\"') {
                    continue;
                }
                commands[command_index][argument_index][k] = current_char;
                k++;
            }
            commands[command_index][argument_index][k] = '\0';
            argument_index++;
            tokens++;
        }
    }

    // terminate last command and set next command to NULL
    commands[command_index][argument_index] = NULL;
    commands[command_index + 1][0] = NULL;

    if( !strcmp(commands[0][0],"history")){
    }
    if (!strncmp(commands[0][0],"!",1)){
        if(!strncmp(commands[0][0],"!!",2)){  //제일 최근 명령어 찾기 
            if(strlen(commands[0][0])==2){
                memset(commands[0][0], 0, sizeof(commands[0][0])); 
                strcpy(commands[0][0],lastline); 
            }
            else if(strlen(commands[0][0])>2){
                char temp[100] ;
                char newcmdline[100] ; 
                char *pos = strstr(commands[0][0], "!!") ; 
                if(pos!=NULL){
                    strncpy(temp, commands[0][0], pos-commands[0][0]) ; 
                    temp[pos-commands[0][0]] = '\0' ; 
                    lastline[strcspn(lastline, "\n")]= '\0' ; 
                    strcat(temp ,lastline) ; 
                    strcat(temp, pos+2) ; 
                    strcpy(newcmdline, temp) ; 
                    memset(commands[0][0], 0, sizeof(commands[0][0]));
                    strcpy(commands[0][0], newcmdline) ;
                    
                }
            }
        }
        else{
            char *num_pos = commands[0][0] ; 
            if(strncmp(num_pos,"!", 1)==0){
                int num ; 
                if(sscanf(num_pos+1, "%d",&num)==1){
                }
                fseek(pipefp,0, SEEK_SET) ; 
                int line_number = 1 ;
                char numline[50] ; 
                char torun[50] ; 
                     while (fgets(line, sizeof(line), pipefp)) {
                        strcpy(numline, line);
                        if(line_number == num){
                            strcpy(torun , numline) ;
                        }
                        line_number ++;
                     }
                     memset(commands[0][0], 0, sizeof(commands[0][0]));
                     torun[strcspn(torun,"\n")]= '\0';  
                    strcpy(commands[0][0], torun) ;
            }
        }
    }
    fclose(pipefp) ; 
    return commands;
}
void freeLast(char*** commands)
{
	for (int i = 0; i < MAXARGS; i++) {
		for (int j = 0; j < MAXARGS; j++) {
			free(commands[i][j]);
		}
		free(commands[i]);
	}
	free(commands);
}
