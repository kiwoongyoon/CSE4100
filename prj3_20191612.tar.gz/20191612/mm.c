/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 *
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
	/* Your student ID */
	"20191612",
	/* Your full name*/
	"Kiwoong Yoon",
	/* Your email address */
	"rldnddbs@naver.com",
};
typedef unsigned int u_int;
typedef unsigned long long u_llong;
/* $begin mallocmacros */
/* Basic constants and macros */
#define WSIZE       	4       /* Word and header/footer size (bytes) */ 
#define DSIZE       	8       /* Doubleword size (bytes) */
#define CHUNKSIZE  		4096  /* Extend heap by this amount (bytes) */ 
#define REBUF           64
#define ListNum			16 //새로 만든 세그리스트 개수 
/* Pack a size and allocated bit into a word */
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define ALIGN(size) (((size_t)(size) + (DSIZE-1)) & ~0x7)
#define PACK(size, alloc)  ((size) | (alloc)) 

/* Given block ptr bp, compute address of its header and footer */
#define HDRP(bp)       ((char *)(bp) - WSIZE)                      
#define FTRP(bp)       ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE) 

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(bp)  ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE))) 
#define PREV_BLKP(bp)  ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE))) 

/* Read and write a word at address p */
#define GET(p)				(*(u_int *)(p))          
#define PUT(p, val)			(*(u_int*)(p) = (val))   


//////////////////////////////////////////////////////////////////////////
#define SET_PTR(p, ptr)		(*(u_int *)(p) = (u_int)(ptr)) //to make p points to pointer ptr 
#define PUT_TAG(p, val)		(*(u_int *)(p) = (val) | GET_TAG(p)) //(*(u_int *)(p) = (val) | GET_TAG(p))
/* Read the free block's reallocation tag */
#define GET_TAG(p)   (GET(p) & 0x2)

/* Read the size and allocated fields from address p */
#define GET_SIZE(p)			(GET(p) & ~0x7)               
#define GET_ALLOC(p)		(GET(p) & 0x1) //check whether it is allocated     

/* Set/remove the free block's reallocation tag */


/* ## SEGREGATED LIST MACROS ## */
#define PREV_PTR(bp)	((char *)(bp))
#define NEXT_PTR(bp)	((char *)(bp) + WSIZE)
/* Compute address of next & prev free block entries */
#define NOW_FREE(bp)		(*(char **)(bp))
#define NEXT_FREE(bp)		(*(char **)(bp + WSIZE))

/* Global variables */
static void* slist1, *slist2, *slist3, *slist4, *slist5, * slist6, * slist7, * slist8;
static void* slist9, * slist10, * slist11, * slist12, *slist13, * slist14, * slist15, * slist16;

/* Function prototypes for internal helper routines */
static void* extend_heap(size_t words);
static void seg_insert(char* bp, size_t size);
static void seg_remove(char* bp);
static void* coalesce(void* bp);
static void* place(void* bp, size_t asize);
/* Function prototypes for debugging routines */
int mm_check();



/******************************
 * DYNAMIC MEMORY ALLOCATOR PKG
 ******************************/

/*
 * mm_init - initialize an empty heap: return -1 on error, 0 on NEXT_FREEess.
 */
int mm_init()
{
	void* firstmemory;
	void** slists[ListNum] = {
		&slist1, &slist2, &slist3, &slist4,	&slist5, &slist6, &slist7, &slist8,
		&slist9, &slist10, &slist11, &slist12,&slist13, &slist14, &slist15, &slist16,
	};
	/* Initialize segregated free lists */
	for (int i = 0; i < ListNum; i++) {
		*slists[i] = NULL;
	}
	/* Check for error then initialize empty heap */
	if (!(firstmemory = mem_sbrk(4 * WSIZE)) ){return -1; }

	 /* Set up the heap with padding, prologue, and epilogue */
	PUT(firstmemory, 0);
	PUT(firstmemory + WSIZE, PACK(DSIZE, 1));
	PUT(firstmemory + (2 * WSIZE), PACK(DSIZE, 1));
	PUT(firstmemory + (3 * WSIZE), PACK(0, 1));

     /* Extend the empty heap with a free block of CHUNKSIZE bytes */
	if (!extend_heap(CHUNKSIZE) ){ return -1; }
	else {return 0; }
}

/*
 * mm_malloc - memory allocation.. allocate requested size (bytes)
 */
void* mm_malloc(size_t size)
{
	// Array of segregated lists
	void** slists[ListNum] = {
		&slist1, &slist2, &slist3, &slist4,	&slist5, &slist6, &slist7, &slist8,
		&slist9, &slist10, &slist11, &slist12,&slist13, &slist14, &slist15, &slist16,
	};

	char* bp ; 
	int i = 0;
	size_t asize, ext_size;      /* Adjusted block size */ /* Amount to extend heap if no fit */

	// Trivial call to malloc
	if (!size) {return NULL;}

	/* Adjust block size to include overhead and alignment reqs. */
	if (size <= DSIZE) { 
		// If size is small, allocate a minimum block size
		asize = 2 * DSIZE;
	} else {
		// If size is large, adjust to the next multiple of DSIZE
		asize = DSIZE * ((size + (DSIZE) + (DSIZE - 1)) / DSIZE); // asize = ((size + (DSIZE - 1)) / DSIZE) * DSIZE;
	}

	// Search for a free block in the segregated lists
	for (i = 0; i < ListNum; i++) {
		if (*slists[i] != NULL && ((asize <= (1 << (i + 4))) || i == (ListNum - 1))) {
			bp = *slists[i];
			while (bp != NULL && ((asize > GET_SIZE(HDRP(bp))) )) {
				// Iterate through the blocks until a suitable one is found
				
				bp = NEXT_FREE(bp);

			}if (bp != NULL) {
				// If a suitable block is found, allocate the requested size in it
				return place(bp, asize);
			}
		}
	}
	// No suitable block found, extend the heap
	ext_size = (asize > CHUNKSIZE)? asize : CHUNKSIZE ; 
	if ((bp = extend_heap(ext_size)) == NULL) {return NULL;}
	// Allocate the requested size in the newly extended block
	return place(bp, asize);
}



/*
 * mm_free - free block of memory starting at bp
 */
void mm_free(void* bp)
{
	/* Specific case checks -- */
	if (!bp ) {return;}
	size_t size = GET_SIZE(HDRP(bp));
	// Mark the block as unallocated
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
	// Insert the freed block into the segregated list
	seg_insert(bp, size);
	// Coalesce the freed block with neighboring blocks if possible
	coalesce(bp);
}

/*
 * coalesce - Coalesce adjacent free blocks (if any), 
 *            add coalesced block to free list,
 *            and return ptr to block.
 */

static void* coalesce(void* bp)
{
	// Extract allocation status of previous and next blocks
	size_t prev_alloc = GET_ALLOC(HDRP(PREV_BLKP(bp)));
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	size_t size = GET_SIZE(HDRP(bp));

	if (prev_alloc && next_alloc) {            /* Case 1: Both neighboring blocks are allocated */
		return bp;
	}
	else if (prev_alloc && !next_alloc) {      /* Case 2: Only the next block is unallocated */
		// Update the size of the current block by combining with the next block
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		// Remove the blocks from the segregated list
		seg_remove(bp);
		seg_remove(NEXT_BLKP(bp));

		PUT_TAG(HDRP(bp), PACK(size, 0));
		PUT_TAG(FTRP(bp), PACK(size, 0));
	}
	else if (!prev_alloc && next_alloc) {      /* Case 3: Only the previous block is unallocated */
		// Update the size of the previous block by combining with the current block
		size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		// Remove the blocks from the segregated list
		seg_remove(PREV_BLKP(bp));
		seg_remove(bp);

		PUT_TAG(FTRP(bp), PACK(size, 0));
		PUT_TAG(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
	}
	else {                                     /* Case 4: Both neighboring blocks are unallocated */
		// Update the size of the previous block by combining with the current and next blocks
		size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(HDRP(NEXT_BLKP(bp)));
		// Remove the blocks from the segregated list
		seg_remove(PREV_BLKP(bp));
		seg_remove(bp);
		seg_remove(NEXT_BLKP(bp));

		PUT_TAG(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		PUT_TAG(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);

	}
	// Insert the coalesced block back into the segregated list
	seg_insert(bp, size);

	return bp;
}
/*
 * seg_insert - insert a free block into the appropriate
 *               segregated list based on its size
 */
static void seg_insert(char* bp, size_t size)
{
	void* first = NULL;             // Pointer to the head of the segregated list
	void* prev = NULL;           // Pointer to the block before the current block
	int i = 0;                      // Index for finding the appropriate segregated list
	int check = ListNum - 1;       // Index of the last segregated list
	int flag = 0;  // Flag to indicate if a suitable block is found
	void** slists[ListNum] = {
		&slist1, &slist2, &slist3, &slist4,		&slist5, &slist6, &slist7, &slist8,
		&slist9, &slist10, &slist11, &slist12,		&slist13, &slist14, &slist15, &slist16,
	};

	// Find the appropriate segregated list based on block size
	while (i < ListNum && !(size <= (1 << (i + 4))) && !(i == check)) {
		i++;
	}
	
	first = *slists[i];

	while (first && !flag) {
		if (size <= GET_SIZE(HDRP(first))) {
			flag = 1;  // Set flag to indicate a suitable block is found
		} else {
			prev = first;
			first = NEXT_FREE(first);
		}
	}

	// If no suitable block is found, insert the current block at the end of the list
	if (first == NULL) {
		if (prev != NULL) { /* when only one node  */
			SET_PTR(PREV_PTR(bp), prev);
			SET_PTR(NEXT_PTR(bp), NULL);
			SET_PTR(NEXT_PTR(prev), bp);
		}
		if (prev == NULL) { /* when nothing was there  */
			SET_PTR(PREV_PTR(bp), NULL);
			SET_PTR(NEXT_PTR(bp), NULL);
			*slists[i] = bp;  // Update the head of the segregated list
		}
	}

	// If a suitable block is found, insert the current block in the middle or at the beginning of the list
	if (first != NULL) {
		if (prev != NULL) { /* Mid block */
			SET_PTR(PREV_PTR(bp), prev);
			SET_PTR(NEXT_PTR(prev), bp);
			SET_PTR(NEXT_PTR(bp), first);
			SET_PTR(PREV_PTR(first), bp);
		}
		if (prev == NULL) { /* new node is smaller than the original */
			SET_PTR(PREV_PTR(bp), NULL);
			SET_PTR(NEXT_PTR(bp), first);
			SET_PTR(PREV_PTR(first), bp);
			*slists[i] = bp;  // Update the head of the segregated list in increasing order 
		}
	}
}

/*
 * seg_remove- remove a free block from the segregated list
 */
static void seg_remove(char* bp)
{
	int i = 0;                     // Index for finding the appropriate segregated list
	int check = ListNum - 1;       // Index of the last segregated list
	size_t size = GET_SIZE(HDRP(bp));
	void** slists[ListNum] = {&slist1, &slist2, &slist3, &slist4,&slist5, &slist6, &slist7, &slist8,
		&slist9, &slist10, &slist11, &slist12,&slist13, &slist14, &slist15, &slist16,
	};

	// Find the appropriate segregated list based on block size
	while (i < ListNum && !(size <= (1 << (i + 4))) && !(i == check)) {i++;}
	// Check if the block is the last block in the segregated list
	if (NEXT_FREE(bp) == NULL) {
		if (NOW_FREE(bp)) { 
			SET_PTR(NEXT_PTR(NOW_FREE(bp)), NULL);
		} else { 
			*slists[i] = NULL;  // Update the head of the segregated list
		}
	}
	// If the block is not the last block, remove it from the middle or at the beginning of the list
	if (NEXT_FREE(bp)) {
		if (NOW_FREE(bp)) { //중간의 노드를 변경하는 경우 
			SET_PTR(NEXT_PTR(NOW_FREE(bp)), NEXT_FREE(bp));
			SET_PTR(PREV_PTR(NEXT_FREE(bp)), NOW_FREE(bp));
		} else { //
			SET_PTR(PREV_PTR(NEXT_FREE(bp)), NULL);
			*slists[i] = NEXT_FREE(bp);  // Update the head of the segregated list
		}
	}
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 */
void* mm_realloc(void* ptr, size_t size)
{
	char* new_ptr;
	int remainder;
	int extend_size;
	int diff;
	/* If ptr is NULL, then this is just malloc. */
	if (!ptr ) {
		return mm_malloc(size);  // Allocate a new memory block
	}else{new_ptr = ptr;}
	/* If size == 0 then this is just free, and we return NULL. */
	if (!size ) {
		mm_free(ptr);  // Free the memory block
		return 0;	}
	
	size_t new_size;
	if (size <= DSIZE) {
		new_size = 2 * DSIZE;  // Adjust new size to meet minimum size requirements
	} else {
		new_size = DSIZE * ((size + (DSIZE)+(DSIZE - 1)) / DSIZE);  // Adjust new size for alignment and overhead
	}

	//new_size += REBUF;  // Add a buffer to new size for reallocation

	diff = GET_SIZE(HDRP(ptr)) - new_size;  // Calculate the size difference between the current block and new size

	if (diff < 0) {  // If block size is negative, we need to reallocate
		if (GET_ALLOC(HDRP(NEXT_BLKP(ptr))) && GET_SIZE(HDRP(NEXT_BLKP(ptr)))) {
			// Next block is allocated, so we cannot extend into it
			size_t tocpy = (size< new_size)? size : new_size ; 
			new_ptr = mm_malloc(new_size - DSIZE);  // Allocate a new block with the adjusted size
			memcpy(new_ptr, ptr, tocpy);  // Copy the contents from the old block to the new block
			mm_free(ptr);  // Free the old block
		} else {
			// Next block is free, so we can extend into it
			remainder = GET_SIZE(HDRP(ptr)) + GET_SIZE(HDRP(NEXT_BLKP(ptr))) - new_size;  // Calculate the remaining size after extending
			if (remainder < 0) {  // If remaining size is negative, we need to extend the heap
				int newremain = (-1)*remainder ; 
				extend_size = (CHUNKSIZE > newremain)? CHUNKSIZE : newremain ; 
				// Extend the heap and handle the error case
				if (!(extend_heap(extend_size)) ){return 0;}

				remainder += extend_size;  // Update the remaining size after extending
			}
			seg_remove(NEXT_BLKP(ptr));  // Remove the next block from the segregated list

			// Update the header and footer of the current block with the new size
			PUT(HDRP(ptr), PACK(new_size + remainder, 1));
			PUT(FTRP(ptr), PACK(new_size + remainder, 1));
		}

		diff = GET_SIZE(HDRP(new_ptr)) - new_size;  // Update the block size after reallocation
	}

	return new_ptr;  // Return the pointer to the reallocated memory block
}


/****************************
 * HELPER FUNCTIONS FROM TEXT
 ****************************/

/* 
 * extend_heap - Extend heap with free block and return its block pointer
 */
static void* extend_heap(size_t words)
{
	size_t newsize = ALIGN(words); 
	char* bp;

	// Extend the heap by the specified number of words using mem_sbrk
	if ((long)(bp = mem_sbrk(newsize)) == -1) return NULL;  // Return NULL if mem_sbrk fails to extend the heap
	// Set the header and footer of the newly allocated block
	PUT(HDRP(bp), PACK(newsize, 0));  // Set the header with the adjusted size and mark the block as unallocated
	PUT(FTRP(bp), PACK(newsize, 0));  // Set the footer with the adjusted size and mark the block as unallocated

	// Set the header of the next block as the epilogue block
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1));  // Set the header with size 0 and mark the block as allocated

	// Insert the newly extended block into the appropriate segregated list
	seg_insert(bp, newsize);

	// Coalesce the newly extended block with adjacent free blocks if possible
	return coalesce(bp); 
}

/* 
 * place - Place block of asize bytes at start of free block bp 
 *         and split if remainder would be at least minimum block size
 * 			used when mallocing the memory 
 */
static void* place(void* bp, size_t asize)
{
	size_t csize = GET_SIZE(HDRP(bp));  // Get the size of the current block

	seg_remove(bp);  // Remove the block from the segregated list

	if ((csize - asize) >= (2 * DSIZE)) { /* block division */
		if ((csize*0.9>=asize && csize*0.10<asize ) ) {  // If the requested size is within a specific range
			//csize*0.88>=asize && csize*0.12<asize 
			PUT(HDRP(bp), PACK(asize, 1));  // Set the header of the current block with the requested size and mark the block as allocated
			PUT(FTRP(bp), PACK(asize, 1));  // Set the footer of the current block with the requested size and mark the block as allocated
			PUT(HDRP(NEXT_BLKP(bp)), PACK(csize - asize, 0));  // Set the header of the remaining block with the remaining size and mark the block as unallocated
			PUT(FTRP(NEXT_BLKP(bp)), PACK(csize - asize, 0));  // Set the footer of the remaining block with the remaining size and mark the block as unallocated
			seg_insert(NEXT_BLKP(bp), csize - asize);  // Insert the remaining block into the segregated list

			return bp;  // Return the current block
		}
		else {
			PUT(HDRP(bp), PACK(csize - asize, 0));  // Set the header of the current block with the remaining size and mark the block as unallocated
			PUT(FTRP(bp), PACK(csize - asize, 0));  // Set the footer of the current block with the remaining size and mark the block as unallocated
			PUT(HDRP(NEXT_BLKP(bp)), PACK(asize, 1));  // Set the header of the newly allocated block with the requested size and mark the block as allocated
			PUT(FTRP(NEXT_BLKP(bp)), PACK(asize, 1));  // Set the footer of the newly allocated block with the requested size and mark the block as allocated
			seg_insert(bp, csize - asize);  // Insert the current block into the segregated list

			return NEXT_BLKP(bp);  // Return the newly allocated block
		}
	}
	else { /* block division x */
		PUT(HDRP(bp), PACK(csize, 1));  // Set the header of the current block with the original size and mark the block as allocated
		PUT(FTRP(bp), PACK(csize, 1));  // Set the footer of the current block with the original size and mark the block as allocated
		return bp;  // Return the current block
	}
}

int mm_check()
{
	// Array of segregated lists
	void** slists[ListNum] = {&slist1, &slist2, &slist3, &slist4,&slist5, &slist6, &slist7, &slist8,&slist9, &slist10, &slist11, &slist12,
	&slist13, &slist14, &slist15, &slist16	};

	void* first;
	int answer = 1;
	// Iterate through each segregated list
	for (int i = 0; i < ListNum; i++) {
		if (!(*slists[i]) ){continue;}

		first = *slists[i];

		// Traverse each block in the segregated list
		while (first) {
			if (GET_SIZE(HDRP(first)) != GET_SIZE(FTRP(first))) {
				// Check if the header size and footer size are not equal
				printf("Header and Footer is not same \n");
				answer = -1;
			}
			else {
				if ((i == ListNum - 1) && (GET_SIZE(HDRP(first)) <= (1 << (i + 3)))) {
					// Check if the block is in the last segregated list and its size is too small
					printf("Not enough headsize. Origin size: %d, Header's size: %d\n",(1 << (i + 3)), GET_SIZE(HDRP(first)));
					
					answer = -1;
				}
				else if ((i == 0) && (GET_SIZE(HDRP(first)) != 16)) {
					// Check if the block is in the first segregated list and its size is not 16
					printf("Size is not fittable header size : %d\n", GET_SIZE(HDRP(first)));
					
					answer = -1;
				}
			}
			first = NEXT_FREE(first);  // Move to the next block in the segregated list
		}
	}

	return answer;
}
