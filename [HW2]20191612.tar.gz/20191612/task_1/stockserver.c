#include "csapp.h"

#define MAXSTOCK 1024

typedef struct {	// connected descriptor pool
	int maxfd;
	fd_set read_set;
	fd_set ready_set;
	int nready;	// number of ready descriptor
	int maxi;
	int clientfd[FD_SETSIZE];	// active socket descriptors
	rio_t clientrio[FD_SETSIZE];	// read buffers
} pool;

typedef struct {	// stock item
	int ID;		// stock id
	int remain;	// number of left stock
	int price;	// stock price
} Stock;

typedef struct _Node{		// node of stock binary search tree
	struct _Node* left;		// left child
	struct _Node* right;	// right child
	Stock data;				// stock data
} Node;

void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p);

void parseline(char*, char**);

Node* instnode(Node* root, Node* n);
void free_node(Node*);
void stockshow(Node*, char []);
Stock* stockfind(Node*, int);
void buy(Stock*, int);
void sell(Stock*, int);
void myHandler(int);
void storestocks(Node* , FILE*) ;
Node* stocktree = NULL;	// stocktree of stock BST
int listenfd;		// receive request by listenfd

int main(int argc, char **argv) 
{
	int ID, remains, price;
    int connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
	static pool pool;
	char client_hostname[MAXLINE], client_port[MAXLINE];

	Signal(SIGINT, myHandler);	// call sigint_hander function when receive ctrl+c 
	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}

	

	FILE* fp;
	fp = fopen("stock.txt", "r");
	
	// read all stocks from stored data
	while (fscanf(fp, "%d%d%d", &ID, &remains, &price) != EOF){
		Node* onestock = (Node *)malloc(sizeof(Node));
		onestock->left = onestock->right = NULL;
		onestock->data.ID = ID;
		onestock->data.remain = remains;
		onestock->data.price = price;

		
		stocktree = instnode(stocktree, onestock);
	}

	fclose(fp);



	listenfd = Open_listenfd(argv[1]);
	init_pool(listenfd, &pool);

    while (1) {
		// wait for listening/connected descriptor to become ready
		pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);
		
		// if listening descriptor ready, add new client to pool
		if (FD_ISSET(listenfd, &pool.ready_set)) {
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
			Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
			printf("Connected to (%s, %s)\n", client_hostname, client_port);
			add_client(connfd, &pool);
		}

		// process input from each ready connected descriptor
		check_clients(&pool);
    }
	FILE *fp1 ; 
	fp1 = fopen("stock.txt", "w"); 
	if(stocktree !=NULL){
		if(fp1 !=NULL){
			storestocks(stocktree, fp1) ; 
		}
	}
	fclose(fp1) ; 
	
	Close(listenfd);

	return 0;
}
void storestocks(Node* stocktree, FILE* fp ){
	if(stocktree ==NULL){
		return; 
	}
	fprintf(fp, "%d %d %d\n", stocktree->data.ID, stocktree->data.remain, stocktree->data.price);
	storestocks(stocktree->left , fp) ; 
	storestocks(stocktree->right , fp) ; 


}
void init_pool(int listenfd, pool *p)
{
	// initailly there are no connected descriptor
	int i;
	p->maxi = -1;

	for(i = 0; i < FD_SETSIZE; i++)
		p->clientfd[i] = -1;

	// initially, listenfd is only member of select read set
	p->maxfd = listenfd;
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool *p)
{
	int i;
	p->nready--;
	for (i = 0; i < FD_SETSIZE; i++) {
		if (p->clientfd[i] < 0) {
			// add connected descriptor to the pool
			p->clientfd[i] = connfd;
			Rio_readinitb(&p->clientrio[i], connfd);

			// add the descriptor to descriptor set
			FD_SET(connfd, &p->read_set);

			// update max descriptor and pool high water mark
			if (connfd > p->maxfd)
				p->maxfd = connfd;
			if (i > p->maxi)
				p->maxi = i;
			break;
		}
	}

	if (i == FD_SETSIZE)	// couldn't find an empty slot
		app_error("add_client error: Too many clients");
}

void check_clients(pool *p)
{
	int i, connfd, n;
	char buf[MAXLINE];
	rio_t rio;

	for (i = 0; (i <= p->maxi) && (p->nready > 0); i++) {
		connfd = p->clientfd[i];
		rio = p->clientrio[i];

		// if the descriptor is ready, send proper response
		if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) {
			p->nready--;
			memset((void*)buf, 0, MAXLINE);		// clear buf
			if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {	// read request from connfd
				int a,b ; 
				char cmd[5] ; 				
			printf("Server received %d bytes \n", n);
				//printf("%s\n", buf);
				sscanf(buf, "%s %d %d",cmd, &a,&b) ;
				if (!strncmp(buf, "show", 4)) {	// show
					strcpy(buf, "");
					stockshow(stocktree, buf);	// write response to buf
					Rio_writen(connfd, buf, MAXLINE);	// send response to connfd
					//continue ; 
				}else if (strcmp(cmd, "sell")==0) {	// sell
					int tid = a;	// get tid
					int tnum = b;		// request count
					Stock* stock = stockfind(stocktree, tid);	// find stock
					if (!stock) {	// stock id not found
						Rio_writen(connfd, "", MAXLINE);
						return;
					}
					sell(stock, tnum);		// add stock
					Rio_writen(connfd, "[sell] success\n", MAXLINE);
				}
				else if (strcmp(cmd, "buy")==0) {	// buy
					int tid =a;	// get tid
					int tnum = b;		// request count

					Stock* stock = stockfind(stocktree, tid);	// find stock
					if (!stock) {	// stock id not found
						Rio_writen(connfd, "", MAXLINE);
						return;
					}
					if (tnum > stock->remain) {		// if not enough left stock
						Rio_writen(connfd, "Not enough left stock\n", MAXLINE);
					}
					else {	// enough stock
						buy(stock, tnum);
						Rio_writen(connfd, "[buy] success\n", MAXLINE);
					}
				}
				
				else if (strncmp(cmd, "exit",4)==0) {	// exit
					Close(connfd);
					FD_CLR(connfd, &p->read_set);
					p->clientfd[i] = -1;
					
				}
			}
			else {
				Close(connfd);
				FD_CLR(connfd, &p->read_set);
				p->clientfd[i] = -1;
			}
		}
	}
}

Node* instnode(Node* stocktree, Node* onestock)
{
	if (stocktree == NULL) {	// if root is NULL
		stocktree =onestock;	// set root to n
		return stocktree;
	}

	if (onestock->data.ID <= stocktree->data.ID) {	// move to left child
		stocktree->left = instnode(stocktree->left, onestock);
	}
	else {	// move to right child
		stocktree->right = instnode(stocktree->right, onestock);
	}
	return stocktree;
}

void free_node(Node* stocktree)
{
	if (!stocktree)	// if stocktree is NULL, exit function
		return;

	free_node(stocktree->left);	// move to left child
	free_node(stocktree->right);	// move to right child

	free(stocktree);	// deallocate memory
}


void stockshow(Node* stocktree, char buf[])
{
	if (!stocktree)
		return;

	// Traverse the left subtree
	stockshow(stocktree->left, buf);	

	// Format the stock data and append it to the buffer
	char temp[30];
	snprintf(temp, sizeof(temp), "%d %d %d\n", stocktree->data.ID, stocktree->data.remain, stocktree->data.price);
	strcat(buf, temp);

	// Traverse the right subtree
	stockshow(stocktree->right, buf);	

	return;
}


Stock* stockfind(Node* stocktree, int ID)
{
	if (!stocktree){
		return NULL;}
	// If the current node's ID matches the target ID, return a pointer to the stock data
	if (stocktree->data.ID == ID){
		return &stocktree->data;}

	// If the target ID is less than the current node's ID, search in the left subtree
	else if (ID < stocktree->data.ID){
		return stockfind(stocktree->left, ID);}

	// If the target ID is greater than the current node's ID, search in the right subtree
	else{
		return stockfind(stocktree->right, ID);}
}

void buy(Stock* stock, int cnt)
{
	// subtract cnt
	stock->remain -= cnt;
}

void sell(Stock* stock, int cnt)
{
	// add cnt
	stock->remain += cnt;
}

void myHandler(int sig)
{
	Close(listenfd);	// close listen file descriptor
	Sio_puts("\n");
	FILE* fp ;    // File  updated stock data
    fp = fopen("stock.txt", "w");
    if (fp) {
        storestocks(stocktree, fp);    // Store the stocks in the file
    }
	fclose(fp);	// close fp
	free_node(stocktree);	// deallocate BST memory

	exit(0);	// terminate process
}

