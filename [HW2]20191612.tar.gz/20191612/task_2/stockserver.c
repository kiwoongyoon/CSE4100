#include "csapp.h"

#define MAXSTOCK 1024
#define threadNumber 20
#define SBUFSIZE 100

typedef struct {
	int *buf;		// buffer array
	int n;			// maximum number of slots
	int front;		// buf[(front+1) % n] is first item
	int rear;		// buf[rear % n] is last item
	sem_t mutex;	// protects accesses to buf
	sem_t slots;	// counts available slots
	sem_t items;	// counts available items
} sbuf_t;

typedef struct {
	int ID;				// stock id
	int remain;			// number of left stock
	int price;			// stock price
	int readcnt;		// number of reading thread
	sem_t read_mutex;	// protect reading accesses to buf
	sem_t write_mutex;	// protect writing accesses to buf
} Stock;

typedef struct _Node{		// node of stock binary search tree
	Stock data;				// stock data
	struct _Node* left;		// left child
	struct _Node* right;	// right child
} Node;


void sbuf_init(sbuf_t *, int);                // Initialize the shared buffer
void sbuf_deinit(sbuf_t *);                    // Deinitialize the shared buffer
void sbuf_insert(sbuf_t *, int);               // Insert a value into the shared buffer
int sbuf_remove(sbuf_t *);                     // Remove a value from the shared buffer
Node* instnode(Node*, Node*);                  // Insert a node into the stock tree
void free_node(Node*);                         // Free memory allocated for a node
void pthread_init();                           // Initialize pthread resources
int buy(Node*, int, int, int);                  // Process a buy request
int sell(Node*, int, int, int);                 // Process a sell request

void stockshow(Node*, char []);                // Generate a response to show the stock information
Stock* stockfind(Node*, int);                   // Find a stock by its ID in the stock tree

void storestocks(Node* , FILE*);                // Store the stock information in a file
void *thread(void*);                            // Pthread entry function for worker threads
void stockecho(int);                            // Handle the stock-related requests from a client

void myHandler(int);                            // Signal handler for SIGINT (Ctrl+C) interruption

Node* stocktree = NULL;	// stocktree of stock BST
int listenfd;		// receive request by listenfd

sbuf_t sbuf;	// producer-consumer thread pool


static sem_t mutex_t;	// protect thread in pool

int main(int argc, char **argv) {
	int connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;  
	pthread_t tid;
	Signal(SIGINT, myHandler);		// Register signal handler for SIGINT (Ctrl+C)
	
	// Check the command-line arguments
	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}

	FILE* fp;
	fp = fopen("stock.txt", "r");
	int ID, remains, price;
	
	// Read stock data from the file and create nodes for each stock
	while (fscanf(fp, "%d%d%d", &ID, &remains, &price) != EOF) {
		Node* onestock = (Node *)malloc(sizeof(Node));
		Sem_init(&onestock->data.read_mutex, 0, 1);	// Initialize read_mutex semaphore
		Sem_init(&onestock->data.write_mutex, 0, 1);	// Initialize write_mutex semaphore
		onestock->left = NULL;
		onestock->right = NULL;
		onestock->data.ID = ID;
		onestock->data.remain = remains;
		onestock->data.price = price;
		onestock->data.readcnt = 0;
		stocktree = instnode(stocktree, onestock);	// Insert the stock into the tree
	}

	fclose(fp);

	listenfd = Open_listenfd(argv[1]);	// Open a listening socket
	sbuf_init(&sbuf, SBUFSIZE);			// Initialize the shared buffer for connections

	for (int i = 0; i < threadNumber; i++)
		Pthread_create(&tid, NULL, thread, NULL);	// Create worker threads

	while (1) {
		clientlen = sizeof(struct sockaddr_storage);
		connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);	// Accept incoming connection
		sbuf_insert(&sbuf, connfd);		// Insert the connection into the shared buffer
	}

	FILE *fp1;
	fp1 = fopen("stock.txt", "w");
	if (stocktree != NULL) {
		if (fp1 != NULL) {
			storestocks(stocktree, fp1);	// Store the stock data back to the file
		}
	}

	fclose(fp1);
	Close(listenfd);	// Close the listening socket

	exit(0);
}

void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = Calloc(n, sizeof(int));        // Allocate memory for the shared buffer
    sp->n = n;                              // Set the size of the buffer
    sp->front = sp->rear = 0;                // Initialize the front and rear indices
    Sem_init(&sp->mutex, 0, 1);              // Initialize the mutex semaphore to control buffer access
    Sem_init(&sp->slots, 0, n);              // Initialize the slots semaphore to track available slots
    Sem_init(&sp->items, 0, 0);              // Initialize the items semaphore to track filled slots
}

void sbuf_deinit(sbuf_t *sp)
{
    Free(sp->buf);                           // Free the memory allocated for the shared buffer
}

void sbuf_insert(sbuf_t *sp, int item)
{
    P(&sp->slots);                           // Wait for an available slot in the buffer
    P(&sp->mutex);                           // Acquire the mutex to access the buffer
    sp->buf[(++sp->rear) % (sp->n)] = item;   // Insert the item into the buffer at the rear index
    V(&sp->mutex);                           // Release the mutex
    V(&sp->items);                           // Signal that an item has been added to the buffer
}

int sbuf_remove(sbuf_t *sp)
{
    int item;
    P(&sp->items);                           // Wait for a filled slot in the buffer
    P(&sp->mutex);                           // Acquire the mutex to access the buffer
    item = sp->buf[(++sp->front) % (sp->n)];  // Remove the item from the buffer at the front index
    V(&sp->mutex);                           // Release the mutex
    V(&sp->slots);                           // Signal that a slot has become available
    return item;                             // Return the removed item
}

void storestocks(Node* stocktree, FILE* fp) {
	// Check if stocktree is NULL
	if (stocktree == NULL) {
		return;
	}
	
	// Write stock data to the file
	fprintf(fp, "%d %d %d\n", stocktree->data.ID, stocktree->data.remain, stocktree->data.price);
	
	// Recursively store stocks in the left and right subtrees
	storestocks(stocktree->left, fp);
	storestocks(stocktree->right, fp);
}

void *thread(void *vargp) {
	// Detach the thread
	Pthread_detach(pthread_self());
	
	while (1) {
		int connfd = sbuf_remove(&sbuf);	// Remove a connection from the buffer
		stockecho(connfd);				// Process the stock data for the client
		Close(connfd);					// Close the connection
	}
}

void stockecho(int connfd)
{
	rio_t rio;
	static pthread_once_t once = PTHREAD_ONCE_INIT;

	Pthread_once(&once, pthread_init);
	Rio_readinitb(&rio, connfd);

	int n;
	char temp[MAXLINE];
	
	while ((n = Rio_readlineb(&rio, temp, MAXLINE))) {
		
		temp[strlen(temp)-1] = ' ' ;  // Remove the trailing newline character
		
		int ttid, ttnum;
		char cmd[5];
		sscanf(temp, "%s %d %d", cmd, &ttid, &ttnum);
		printf("Server received %d bytes \n", n);

		if (strncmp(temp, "show", 4) == 0) {	
			memset(temp, 0, MAXLINE);	// Clear the temporary buffer
			stockshow(stocktree, temp);	// Write the response to the temporary buffer
			Rio_writen(connfd, temp, MAXLINE);	// Send the response to the client
			continue;	// Skip the remaining code in the loop and move to the next iteration
		}
		else if (!strncmp(temp, "buy", 3)) {	
			buy(stocktree, connfd, ttid, ttnum);	// Process the buy request
		}
		else if (!strncmp(temp, "sell", 4)) {
			sell(stocktree, connfd, ttid, ttnum);	// Process the sell request
			continue;	// Skip the remaining code in the loop and move to the next iteration
		}
		else if (!strncmp(temp, "exit", 4)) {	
			break;	// Exit the loop and end the function execution
		}
		
		memset(temp, 0, MAXLINE);	// Clear the temporary buffer for the next iteration
	}
}


void pthread_init()
{
	Sem_init(&mutex_t, 0, 1);	// Initialize mutex semaphore to 1 (unlocked)
	
}

Node* instnode(Node* stocktree, Node* onestock)
{
	if (stocktree == NULL) {		// If the stock tree is empty
		stocktree = onestock;				// Set the stock tree to the new node 'n'
		return stocktree;
	}

	if (onestock->data.ID <= stocktree->data.ID) {	// If the ID of 'n' is less than or equal to the ID of the current node
		stocktree->left = instnode(stocktree->left, onestock);	// Recursively insert 'n' into the left subtree
	}
	else {	// If the ID of 'n' is greater than the ID of the current node
		stocktree->right = instnode(stocktree->right, onestock);	// Recursively insert 'n' into the right subtree
	}

	return stocktree;	// Return the modified stock tree
}


void free_node(Node* stocktree)
{
	if (!stocktree)	{
		return;}

	free_node(stocktree->left);
	free_node(stocktree->right);

	free(stocktree); 
}


int buy(Node* stocktree, int connfd, int tid, int tnum)
{
	if (!stocktree){return 0;}
		

	Stock * st = stockfind(stocktree, tid);	// Find the stock with the given stock ID

	P(&st->write_mutex);	// Acquire write mutex to protect stock modification

	if(st->remain < tnum){
		Rio_writen(connfd, "Not enough left stock\n", MAXLINE);	// Send error message if there is not enough stock available
	}
	else{
		Rio_writen(connfd, "[buy] success\n", MAXLINE);		// Send success message if the purchase is possible
		st->remain -=tnum ;	// Reduce the available stock count
	}

	V(&st->write_mutex);	// Release the write mutex

	return 1;	// Return 1 to indicate successful purchase
}


int sell(Node* stocktree, int connfd, int tid, int tnum)
{
	if (stocktree==NULL){
		return 0;

	}
	Stock * st = stockfind(stocktree, tid);	// Find the stock with the given stock ID
	P(&st->write_mutex);	// Acquire write mutex to protect stock modificatio
	Rio_writen(connfd, "[sell] success\n", MAXLINE);	// Send success message for the sell operation
	st->remain += tnum;	// Increase the available stock count
	V(&st->write_mutex);	// Release the write mutex
	return 1;	// Return 1 to indicate successful sell
}

Stock *stockfind(Node* stocktree, int id)
{
	if(!stocktree){
		return NULL;
	}
	if(stocktree->data.ID == id)
	{
		Stock* send;

		P(&stocktree->data.read_mutex);
		stocktree->data.readcnt++;
		if(stocktree->data.readcnt ==1){
		P(&stocktree->data.write_mutex);}
		V(&stocktree->data.read_mutex);

		send = &stocktree->data;	// Create a pointer to the found stock data

		P(&stocktree->data.read_mutex);
		stocktree->data.readcnt--;
		if(stocktree->data.readcnt ==0){

		V(&stocktree->data.write_mutex);
		}
		V(&stocktree->data.read_mutex);

		return send;	// Return the pointer to the found stock data
	}
	else if(id < stocktree->data.ID)
	{
		return stockfind(stocktree->left, id);	// Recursively search in the left subtree
	}
	else
	{
		return stockfind(stocktree->right, id);	// Recursively search in the right subtree
	}
}



void stockshow(Node* stocktree, char buf[])
{
	//char temp[20];
	if (!stocktree){
		return;
	}
	//printf("hihi\n" ) ; 
	stockshow(stocktree->left, buf);	// move to left child

	char temp[30] ; 
	P(&stocktree->data.read_mutex);	// protect access to read
	stocktree->data.readcnt++;
	P(&stocktree->data.write_mutex);
	V(&stocktree->data.read_mutex);	// allow access to read

	snprintf(temp, sizeof(temp),"%d %d %d\n",stocktree->data.ID,stocktree->data.remain,stocktree->data.price) ;
	strcat(buf,temp) ; 

	P(&stocktree->data.read_mutex);	// protect access to read
	stocktree->data.readcnt--;
	if (stocktree->data.readcnt == 0)	// if there is a blocked writer
		V(&stocktree->data.write_mutex);	// allow access to write
	V(&stocktree->data.read_mutex);	// allow access to read
	
	stockshow(stocktree->right, buf);	// move to right child
	return;
}


void myHandler(int sig)
{
	Close(listenfd);	// close listen file descriptor
	Sio_puts("\n");
	FILE* fp ;    // File  updated stock data
    fp = fopen("stock.txt", "w");
    if (fp) {
        storestocks(stocktree, fp);    // Store the stocks in the file
    }
	fclose(fp);	// close fp
	free_node(stocktree);	// deallocate BST memory

	exit(0);	// terminate process
}

